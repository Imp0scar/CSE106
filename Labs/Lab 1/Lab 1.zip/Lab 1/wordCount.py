import string
def main():

    word = input("Enter a word: ").lower()
    count = 0
    with open('C:\CSE106\Lab 1\Lab 1\PythonSummary.txt', 'r') as file:
   # content = f.read()
        for line in file:
            line = line.strip()
            line = line.lower()
            line = line.translate(line.maketrans("", "", string.punctuation))
            words = line.split(" ")

            for j in words:
                if(word in j):
                    count = count + 1
    print("The word", word, "occurs", count, "times")

if __name__ == "__main__":
    main()